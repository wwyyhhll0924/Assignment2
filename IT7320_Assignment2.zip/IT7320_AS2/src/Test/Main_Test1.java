package Test;

import com.windowtester.runtime.swing.locator.JComboBoxLocator;
import com.windowtester.runtime.swing.SwingWidgetLocator;
import javax.swing.JPanel;
import com.windowtester.runtime.swing.UITestCaseSwing;
import com.windowtester.runtime.IUIContext;
import com.windowtester.runtime.swing.locator.JButtonLocator;
import com.windowtester.runtime.swing.condition.WindowShowingCondition;
import com.windowtester.runtime.swing.condition.WindowDisposedCondition;

public class Main_Test1 extends UITestCaseSwing {

	/**
	* Create an Instance
	 */
	public Main_Test1() {
		super(park_my_car.Main.class);
	}

	/**
	* Main test method.
	*/
	public void testMain_Test1() throws Exception {
		IUIContext ui = getUI();
		ui.click(new JComboBoxLocator("HC2 (Green)", 0, new SwingWidgetLocator(JPanel.class)));
		ui.click(new JComboBoxLocator("2 Hours", 1, new SwingWidgetLocator(JPanel.class)));
		ui.click(new JButtonLocator("Park"));
		ui.wait(new WindowShowingCondition("Confirmation"));
		ui.click(new JButtonLocator("��(Y)"));
		ui.wait(new WindowDisposedCondition("Confirmation"));
	}

}