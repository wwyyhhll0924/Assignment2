package Test;

import com.windowtester.runtime.swing.locator.LabeledTextLocator;
import com.windowtester.runtime.swing.UITestCaseSwing;
import com.windowtester.runtime.swing.condition.WindowDisposedCondition;
import com.windowtester.runtime.swing.condition.WindowShowingCondition;
import com.windowtester.runtime.IUIContext;
import java.awt.event.KeyEvent;
import com.windowtester.runtime.WT;
import com.windowtester.runtime.swing.locator.JButtonLocator;

public class Login_potato extends UITestCaseSwing {

	/**
	* Create an Instance
	 */
	public Login_potato() {
		super(park_my_car.Login.class);
	}

	/**
	* Main test method.
	*/
	public void testLogin_potato() throws Exception {
		IUIContext ui = getUI();
		ui.click(new LabeledTextLocator("Password:"));
		ui.enterText("potato");
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText("123456");
		ui.keyClick(KeyEvent.VK_TAB);
		ui.click(new JButtonLocator("Login"));
		ui.click(new JButtonLocator("Login"));
		ui.wait(new WindowShowingCondition("��Ϣ"));
		ui.click(new JButtonLocator("ȷ��"));
		ui.wait(new WindowDisposedCondition("��Ϣ"));
	}

}