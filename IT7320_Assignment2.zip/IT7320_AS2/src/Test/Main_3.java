package Test;

import com.windowtester.runtime.swing.locator.JComboBoxLocator;
import com.windowtester.runtime.swing.SwingWidgetLocator;
import javax.swing.JPanel;
import com.windowtester.runtime.swing.UITestCaseSwing;
import com.windowtester.runtime.IUIContext;
import java.awt.event.KeyEvent;
import com.windowtester.runtime.WT;
import com.windowtester.runtime.swing.locator.JButtonLocator;
import com.windowtester.runtime.swing.condition.WindowShowingCondition;
import com.windowtester.runtime.swing.condition.WindowDisposedCondition;

public class Main_3 extends UITestCaseSwing {

	/**
	* Create an Instance
	 */
	public Main_3() {
		super(park_my_car.Main.class);
	}

	/**
	* Main test method.
	*/
	public void testMain_3() throws Exception {
		IUIContext ui = getUI();
		ui.click(new JComboBoxLocator("cboxPA", 0, new SwingWidgetLocator(JPanel.class)));
		ui.click(new JComboBoxLocator("HC2 (Green)", 0, new SwingWidgetLocator(JPanel.class)));
		ui.click(new JComboBoxLocator("cboxPD", 0, new SwingWidgetLocator(JPanel.class)));
		ui.click(new JComboBoxLocator("River Bank (Light Blue)", 0, new SwingWidgetLocator(JPanel.class)));
		ui.click(new JButtonLocator("Park"));
		ui.wait(new WindowShowingCondition("Confirmation"));
		ui.click(new JButtonLocator("��(Y)"));
		ui.wait(new WindowDisposedCondition("Confirmation"));
	}

}