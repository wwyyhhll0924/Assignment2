package Test;

import com.windowtester.runtime.swing.UITestCaseSwing;
import com.windowtester.runtime.IUIContext;
import com.windowtester.runtime.swing.locator.LabeledTextLocator;
import java.awt.event.KeyEvent;
import com.windowtester.runtime.WT;
import com.windowtester.runtime.swing.locator.JButtonLocator;
import com.windowtester.runtime.swing.condition.WindowShowingCondition;
import com.windowtester.runtime.swing.condition.WindowDisposedCondition;

public class Login_asd123 extends UITestCaseSwing {

	/**
	* Create an Instance
	 */
	public Login_asd123() {
		super(park_my_car.Login.class);
	}

	/**
	* Main test method.
	*/
	public void testLogin_asd123() throws Exception {
		IUIContext ui = getUI();
		ui.click(new LabeledTextLocator("Password:"));
		ui.enterText("asd123");
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText("123456");
		ui.click(new JButtonLocator("Login"));
		ui.click(new JButtonLocator("Login"));
		ui.wait(new WindowShowingCondition("��Ϣ"));
		ui.click(new JButtonLocator("ȷ��"));
		ui.wait(new WindowDisposedCondition("��Ϣ"));
	}

	protected void account_001() throws Exception {
		// TODO Auto-generated method stub
	}

}