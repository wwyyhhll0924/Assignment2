package Test;

import com.windowtester.runtime.swing.locator.LabeledTextLocator;
import com.windowtester.runtime.swing.UITestCaseSwing;
import com.windowtester.runtime.IUIContext;
import java.awt.event.KeyEvent;
import com.windowtester.runtime.WT;
import com.windowtester.runtime.swing.locator.JButtonLocator;
import com.windowtester.runtime.swing.condition.WindowShowingCondition;
import com.windowtester.runtime.swing.locator.NamedWidgetLocator;
import com.windowtester.runtime.swing.condition.WindowDisposedCondition;

public class Register_b extends UITestCaseSwing {

	/**
	* Create an Instance
	 */
	public Register_b() {
		super(park_my_car.Register.class);
	}

	/**
	* Main test method.
	*/
	public void testRegister_b() throws Exception {
		String x = "i";
		IUIContext ui = getUI();
		ui.click(new LabeledTextLocator("Username:"));
		ui.enterText(x);
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText(x);
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText(x);
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText(x);
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText(x);
		ui.keyClick(KeyEvent.VK_TAB);
		ui.click(new JButtonLocator("Register"));
		ui.wait(new WindowShowingCondition("��Ϣ"));
		ui.click(new JButtonLocator("ȷ��"));
		ui.wait(new WindowDisposedCondition("��Ϣ"));
	}

}