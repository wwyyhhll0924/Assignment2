package Test;

import com.windowtester.runtime.swing.locator.LabeledTextLocator;
import com.windowtester.runtime.swing.UITestCaseSwing;
import com.windowtester.runtime.IUIContext;
import java.awt.event.KeyEvent;
import com.windowtester.runtime.WT;
import com.windowtester.runtime.swing.locator.JButtonLocator;
import com.windowtester.runtime.swing.condition.WindowShowingCondition;
import com.windowtester.runtime.swing.condition.WindowDisposedCondition;

public class Register_tomato extends UITestCaseSwing {

	/**
	* Create an Instance
	 */
	public Register_tomato() {
		super(park_my_car.Register.class);
	}

	/**
	* Main test method.
	*/
	public void testRegister_tomato() throws Exception {
		IUIContext ui = getUI();
		ui.click(new LabeledTextLocator("Username:"));
		ui.enterText("tomato");
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText("654321");
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText("654321");
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText("tomato@potato.co.nz");
		ui.keyClick(KeyEvent.VK_TAB);
		ui.enterText("TP5432");
		ui.keyClick(KeyEvent.VK_TAB);
		ui.click(new JButtonLocator("Register"));
		ui.wait(new WindowShowingCondition("Registration Success"));
		ui.click(new JButtonLocator("��(Y)"));
		ui.wait(new WindowDisposedCondition("Registration Success"));
	}

}