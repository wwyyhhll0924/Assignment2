package park_my_car;

import java.sql.*;
import javax.swing.*;


public class sqliteConnection {

	private Connection myConn;
	
	public static Connection DBConnect() {
		
		//Path for "PMC.sqlite" in "park_my_car" file 
		String path = "C:\\Users\\MSI\\eclipse-workspace\\IT7320_AS2\\src\\park_my_car\\PMC.sqlite";
		String dbUrl = "jdbc:sqlite:" + path;
		
		try {
			Class.forName("org.sqlite.JDBC");
			Connection myConn = DriverManager.getConnection(dbUrl);
			System.out.println("initializing database...");
			return myConn;
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
		
	}
	
}
