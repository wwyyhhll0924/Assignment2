package park_my_car;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.*;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private JTextField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	//SQLite Connection
	Connection myConn = null;
	
	public void SQLiteConnection() {
		myConn = sqliteConnection.DBConnect();
	}
	
	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("Park My Car - Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 540);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Calibri", Font.BOLD, 30));
		lblUsername.setBounds(144, 121, 153, 36);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Calibri", Font.BOLD, 30));
		lblPassword.setBounds(144, 209, 153, 36);
		contentPane.add(lblPassword);
		
		txtUsername = new JTextField();
		lblUsername.setLabelFor(txtUsername);
		txtUsername.setFont(new Font("Calibri", Font.PLAIN, 30));
		txtUsername.setBounds(301, 118, 340, 42);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JTextField();
		lblPassword.setLabelFor(txtPassword);
		txtPassword.setFont(new Font("Calibri", Font.PLAIN, 30));
		txtPassword.setColumns(10);
		txtPassword.setBounds(301, 206, 340, 42);
		contentPane.add(txtPassword);
		
		JLabel lblACmsg = new JLabel("");
		lblACmsg.setForeground(Color.RED);
		lblACmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblACmsg.setBounds(301, 164, 420, 36);
		contentPane.add(lblACmsg);
		
		JLabel lblPWmsg = new JLabel("");
		lblPWmsg.setForeground(Color.RED);
		lblPWmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblPWmsg.setBounds(301, 253, 420, 36);
		contentPane.add(lblPWmsg);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String ac = txtUsername.getText().toLowerCase();
					String pw = txtPassword.getText().toLowerCase();
					
					String ACmsg = "Please enter your username";
					String PWmsg = "Please enter your password";
					
					lblACmsg.setText("");
					lblPWmsg.setText("");
					
					if ((ac.equals(""))||(pw.equals(""))) {
						if (ac.equals(""))
							lblACmsg.setText(ACmsg);
						if (pw.equals(""))
							lblPWmsg.setText(PWmsg);
					} else {
						String query = "select * from User where username=? and password=? ";
						PreparedStatement myStmt = myConn.prepareStatement(query);
						myStmt.setString(1, ac);
						myStmt.setString(2, pw);
						
						ResultSet myRS = myStmt.executeQuery();
						int count = 0;
						
						while(myRS.next())
							count = count + 1;		
						
						if (count == 1) {
							//test
							System.out.println("Login success!");
							JOptionPane.showMessageDialog(null,"Login Succuss, Welcome to 'Park My Car'");
							Main main = new Main();
							main.setVisible(true);
							dispose();
						} else {
							//test
							System.out.println("Login fail!");
							JOptionPane.showMessageDialog(null,"Login Fail, Invailed username or password. Please try again.");
							
						}
						myRS.close();
						myStmt.close();
					}
					
				} catch (Exception error) {
					JOptionPane.showMessageDialog(null, error);
				}
			}
		});
		btnLogin.setFont(new Font("Calibri", Font.BOLD, 30));
		btnLogin.setBounds(202, 324, 165, 45);
		contentPane.add(btnLogin);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Register register = new Register();
				register.setVisible(true);
				dispose();
			}
		});
		btnRegister.setFont(new Font("Calibri", Font.BOLD, 30));
		btnRegister.setBounds(424, 324, 165, 45);
		contentPane.add(btnRegister);
		
		
		//SQLite Connection
		SQLiteConnection();
	}
}
