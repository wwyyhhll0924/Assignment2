package park_my_car;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;
import java.awt.Desktop;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Calculate Parking Fee
	 */
	public double calculateFee(double cost, double hour) {
		return cost * hour;
	}
	
	
	
	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("Park My Car - Parking");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPA = new JLabel("Parking Area:");
		lblPA.setFont(new Font("Calibri", Font.BOLD, 30));
		lblPA.setBounds(116, 109, 175, 36);
		contentPane.add(lblPA);
		
		JComboBox cboxPA = new JComboBox();
		cboxPA.setBackground(Color.WHITE);
		lblPA.setLabelFor(cboxPA);
		cboxPA.setModel(new DefaultComboBoxModel(new String[] {"Select Parking Area...", "HC2 (Green)", "HC3 (Yellow)", "HC4 (Orange)", "River Bank (Light Blue)"}));
		cboxPA.setFont(new Font("Calibri", Font.PLAIN, 30));
		cboxPA.setBounds(359, 109, 353, 42);
		contentPane.add(cboxPA);
		
		JLabel lblPD = new JLabel("Parking Duration:");
		lblPD.setFont(new Font("Calibri", Font.BOLD, 30));
		lblPD.setBounds(66, 218, 225, 36);
		contentPane.add(lblPD);
		
		JComboBox cboxPD = new JComboBox();
		cboxPD.setBackground(Color.WHITE);
		lblPD.setLabelFor(cboxPD);
		cboxPD.setModel(new DefaultComboBoxModel(new String[] {"Select Parking Druation..."}));
		cboxPD.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				if ((cboxPA.getSelectedItem().toString()).equals("HC2 (Green)")) {
					cboxPD.setModel(new DefaultComboBoxModel(new String[] {"Select Parking Druation...", "1 Hour", "2 Hours"}));
				} else if ((cboxPA.getSelectedItem().toString()).equals("River Bank (Light Blue)")){
					cboxPD.setModel(new DefaultComboBoxModel(new String[] {"Select Parking Druation...", "1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "6 Hours", "7 Hours"}));
				} else {
					cboxPD.setModel(new DefaultComboBoxModel(new String[] {"Select Parking Druation...", "1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "6 Hours", "7 Hours", "8 Hours"}));
				}
			}
		});
		cboxPD.setFont(new Font("Calibri", Font.PLAIN, 30));
		cboxPD.setBounds(359, 218, 353, 42);
		contentPane.add(cboxPD);
		
		JLabel lblPAmsg = new JLabel("");
		lblPAmsg.setForeground(Color.RED);
		lblPAmsg.setBackground(Color.LIGHT_GRAY);
		lblPAmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblPAmsg.setBounds(359, 159, 431, 36);
		contentPane.add(lblPAmsg);
		
		JLabel lblPDmsg = new JLabel("");
		lblPDmsg.setForeground(Color.RED);
		lblPDmsg.setBackground(Color.LIGHT_GRAY);
		lblPDmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblPDmsg.setBounds(359, 268, 431, 36);
		contentPane.add(lblPDmsg);
		
		JButton btnPark = new JButton("Park");
		btnPark.setFont(new Font("Calibri", Font.BOLD, 30));
		btnPark.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String pa = cboxPA.getSelectedItem().toString();
				String pd = cboxPD.getSelectedItem().toString();
				double hour = 0.00;
				double cost = 0.00;
				
				String PAmsg = "Select your parking area";
				String PDmsg = "Select your parking duration";
				
				String defaultPA = "Select Parking Area...";
				String defaultPD = "Select Parking Druation...";
				
				lblPAmsg.setText("");
				lblPDmsg.setText("");
				
				if ((pa.equals(defaultPA))||(pd.equals(defaultPD))) {
					if (pa.equals(defaultPA))
						lblPAmsg.setText(PAmsg);
					if (pd.equals(defaultPD))
						lblPDmsg.setText(PDmsg);
				} else {
					switch (pa) { // Parking Area Cost
						case "HC2 (Green)": // $1.50 per hour, 2 hours maximum parking duration
							cost = 1.50;
							break;
						case "HC3 (Yellow)": // $1.00 per hour, $6 maximum daily charge
							cost = 1.00;
							break;
						case "HC4 (Orange)": // $0.70 per hour, $4 maximum daily charge
							cost = 0.70;
							break;
						case "River Bank (Light Blue)": // $0.70 per hour, $4 maximum daily charge
							cost = 0.70;
							break;
					}
					switch (pd) { // Parking Duration 
						case "1 Hour":
							hour = 1.00;
							break;
						case "2 Hours":
							hour = 2.00;
							break;
						case "3 Hours":
							hour = 3.00;
							break;
						case "4 Hours":
							hour = 4.00;
							break;
						case "5 Hours":
							hour = 5.00;
							break;
						case "6 Hours":
							hour = 6.00;
							break;
						case "7 Hours": 
							hour = 7.00;
							break;
						case "8 Hours":
							hour = 8.00;
							break;
					}
					double fee = calculateFee(cost,hour);
					System.out.println(hour);
					System.out.println(cost);
					System.out.println(fee);
					String msg = "Parking Area: " + pa + "\nParking Duration: " + pd + "\nFee: $" + fee + "\nConfirm?";
					
					JOptionPane.showConfirmDialog(null, msg, "Confirmation", JOptionPane.YES_NO_OPTION);
				}
			}
		});
		btnPark.setBounds(161, 357, 165, 45);
		contentPane.add(btnPark);
		
		JButton btnMap = new JButton("Map");
		btnMap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mapURL = "https://gissecure.huttcity.govt.nz/parking_map/";
				try {
					Desktop.getDesktop().browse(new URL(mapURL).toURI());
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (URISyntaxException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnMap.setFont(new Font("Calibri", Font.BOLD, 30));
		btnMap.setBounds(497, 357, 165, 45);
		contentPane.add(btnMap);
		
		JLabel lblmsg = new JLabel("*You can check out the parking area by click the \"Map\"  button");
		lblmsg.setFont(new Font("Calibri", Font.PLAIN, 24));
		lblmsg.setBounds(95, 427, 629, 36);
		contentPane.add(lblmsg);
	}
}
