package park_my_car;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private JTextField txtCPassword;
	private JTextField txtEmail;
	private JTextField txtCRN;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * SQLite Connection
	 */
	Connection myConn = null;
	
	public void SQLiteConnection() {
		myConn = sqliteConnection.DBConnect();
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setTitle("Park My Car - Register");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 750);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setHorizontalAlignment(SwingConstants.RIGHT);
		lblUsername.setFont(new Font("Calibri", Font.BOLD, 30));
		lblUsername.setBounds(187, 58, 165, 36);
		contentPane.add(lblUsername);
		
		txtUsername = new JTextField();
		lblUsername.setLabelFor(txtUsername);
		txtUsername.setFont(new Font("Calibri", Font.PLAIN, 30));
		txtUsername.setBounds(366, 55, 395, 42);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lblACmsg = new JLabel("");
		lblACmsg.setForeground(Color.RED);
		lblACmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblACmsg.setBounds(366, 101, 434, 36);
		contentPane.add(lblACmsg);
		
		JLabel lblPWmsg = new JLabel("");
		lblPWmsg.setForeground(Color.RED);
		lblPWmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblPWmsg.setBounds(366, 189, 434, 36);
		contentPane.add(lblPWmsg);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPassword.setFont(new Font("Calibri", Font.BOLD, 30));
		lblPassword.setBounds(201, 144, 151, 36);
		contentPane.add(lblPassword);
		
		txtPassword = new JTextField();
		lblPassword.setLabelFor(txtPassword);
		txtPassword.setFont(new Font("Calibri", Font.PLAIN, 30));
		txtPassword.setColumns(10);
		txtPassword.setBounds(366, 141, 395, 42);
		contentPane.add(txtPassword);
		
		JLabel lblCPWmsg = new JLabel("");
		lblCPWmsg.setForeground(Color.RED);
		lblCPWmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblCPWmsg.setBounds(366, 279, 434, 36);
		contentPane.add(lblCPWmsg);
		
		JLabel lblCPassword = new JLabel("Confirm Password:");
		lblCPassword.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCPassword.setFont(new Font("Calibri", Font.BOLD, 30));
		lblCPassword.setBounds(98, 232, 254, 36);
		contentPane.add(lblCPassword);
		
		txtCPassword = new JTextField();
		lblCPassword.setLabelFor(txtCPassword);
		txtCPassword.setFont(new Font("Calibri", Font.PLAIN, 30));
		txtCPassword.setColumns(10);
		txtCPassword.setBounds(366, 229, 395, 42);
		contentPane.add(txtCPassword);
		
		JLabel lblEmsg = new JLabel("");
		lblEmsg.setForeground(Color.RED);
		lblEmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblEmsg.setBounds(366, 367, 434, 36);
		contentPane.add(lblEmsg);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setHorizontalAlignment(SwingConstants.RIGHT);
		lblEmail.setFont(new Font("Calibri", Font.BOLD, 30));
		lblEmail.setBounds(257, 324, 95, 36);
		contentPane.add(lblEmail);
		
		txtEmail = new JTextField();
		lblEmail.setLabelFor(txtEmail);
		txtEmail.setFont(new Font("Calibri", Font.PLAIN, 30));
		txtEmail.setColumns(10);
		txtEmail.setBounds(366, 321, 395, 42);
		contentPane.add(txtEmail);
		
		JLabel lblCRNmsg = new JLabel("");
		lblCRNmsg.setForeground(Color.RED);
		lblCRNmsg.setFont(new Font("Calibri", Font.PLAIN, 30));
		lblCRNmsg.setBounds(366, 455, 434, 36);
		contentPane.add(lblCRNmsg);
		
		JLabel lblCRN = new JLabel("Car Registration Number:");
		lblCRN.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCRN.setFont(new Font("Calibri", Font.BOLD, 30));
		lblCRN.setBounds(28, 411, 324, 36);
		contentPane.add(lblCRN);
		
		txtCRN = new JTextField();
		lblCRN.setLabelFor(txtCRN);
		txtCRN.setFont(new Font("Calibri", Font.PLAIN, 30));
		txtCRN.setColumns(10);
		txtCRN.setBounds(366, 408, 395, 42);
		contentPane.add(txtCRN);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					String ac = txtUsername.getText().toLowerCase();
					String pw = txtPassword.getText().toLowerCase();
					String cpw = txtCPassword.getText().toLowerCase();
					String email = txtEmail.getText().toLowerCase();
					String crn = txtCRN.getText().toLowerCase();
					
					String ACmsg = "Enter your username";
					String PWmsg = "Enter your password";
					String CPWmsg = "Password does not match";
					String Emsg = "Enter your email";
					String CRNmsg = "Enter your registration number";
					
					lblACmsg.setText("");
					lblPWmsg.setText("");
					lblCPWmsg.setText("");
					lblEmsg.setText("");
					lblCRNmsg.setText("");
					
					if ((ac.equals(""))||(pw.equals(""))||(cpw.equals(""))||(email.equals(""))||(crn.equals(""))) {
						if (ac.equals(""))
							lblACmsg.setText(ACmsg);
						if (pw.equals(""))
							lblPWmsg.setText(PWmsg);
						if (cpw.equals(""))
							lblCPWmsg.setText(PWmsg);
						if (email.equals(""))
							lblEmsg.setText(Emsg);
						if (crn.equals(""))
							lblCRNmsg.setText(CRNmsg);
					} else if (!pw.equals(cpw)) {
							lblCPWmsg.setText(CPWmsg);
					} else {
						String query = "insert into User (username, password, email, crn) values (?, ?, ?, ?)";
						PreparedStatement myStmt = myConn.prepareStatement(query);
						
						myStmt.setString(1, ac);
						myStmt.setString(2, pw);
						myStmt.setString(3, email);
						myStmt.setString(4, crn);
						
						myStmt.executeUpdate();			
						//JOptionPane.showConfirmDialog(null, "Registration Success! Now Login as " + ac, "Registration Success", JOptionPane.YES_OPTION);
						JOptionPane.showMessageDialog(null,"Registration Success! Now Login as " + ac);

						//myRS.close();
						myStmt.close();
						
						Main main = new Main();
						main.setVisible(true);
						dispose();
					}
				} catch (Exception error) {
					JOptionPane.showMessageDialog(null, error);
				}
			}
		});
		btnRegister.setFont(new Font("Calibri", Font.BOLD, 30));
		btnRegister.setBounds(192, 556, 165, 45);
		contentPane.add(btnRegister);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login login = new Login();
				login.setVisible(true);
				dispose();
			}
		});
		btnBack.setFont(new Font("Calibri", Font.BOLD, 30));
		btnBack.setBounds(452, 556, 165, 45);
		contentPane.add(btnBack);
		
		SQLiteConnection();
	}

}
